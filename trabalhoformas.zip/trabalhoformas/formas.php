<center>
<!DOCTYPE html>
<html>
<head>
    <title>Formas geométricas</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Belanosima:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css.css">
</head>
<body>
    <a class="btn btn-dark" href="../index.php" role="button">Inicio</a>
    <a class="btn btn-dark" href="../circulo/index.php" role="button">Círculo</a>
    <a class="btn btn-dark" href="../quadrado/index.php" role="button">Quadrado</a>
    <a class="btn btn-dark" href="../retangulo/index.php" role="button">Retângulo</a>
    <a class="btn btn-dark" href="../triangulo/index.php" role="button">Triângulo</a>
    <a class="btn btn-dark" href="../quadro/index.php" role="button">Quadro</a>
</body>
</html>
</center>