<center>
<?php
require_once('../classes/retangulo.class.php');
require_once('../classes/quadro.class.php');
$retangulo = new Retangulo('',1,1,'x','x',0);

$id = isset($_GET['id'])?$_GET['id']:0;
if ($id > 0){
    $dados = $retangulo->listar(1,$id);
    $editar = new Retangulo($dados[0]['idretangulo'],$dados[0]['base'],$dados[0]['altura'],$dados[0]['cor'],$dados[0]['un'],$dados[0]['idquadro']);
}
?>

<!DOCTYPE html>
<html lang="en">
<title>Formas geométricas</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Belanosima:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css.css">
</head>>
</head>

<body>
    <div class="container">
        <br>
        <?php include "../formas.php"; ?>
        <br><br>
        <h1>Cadastro de Retângulo</h1>
        <section>
                <div class="col-4">
                    <form action="acaoretangulo.php" method="post">
                        <div class="form-group">
                            <label class="pergunta" for="id">ID:</label>
                            <input class="form-control" readonly type="text" name="id" id="id" value="<?php echo isset($editar) ? $editar->getId() : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="lado1">Altura:</label>
                            <input class="form-control" type="text" name='lado1' id='lado1' value='<?php if(isset($editar)) echo $editar->getLado1(); ?>'>
                        </div>
                        <div class="form-group">
                            <label for="lado2">Base:</label>
                            <input class="form-control" type="text" name='lado2' id='lado2' value='<?php if(isset($editar)) echo $editar->getLado1(); ?>'>
                        </div>
                        <div class="form-group">
                            <label class="pergunta" for="un">UN:</label>
                            <select class="form-control" name="un" id="un">
                                <option value="">Selecione</option>
                                <option value="cm" <?php if (isset($editar)) if ($editar->getUn() == 'cm') echo 'selected'; ?>>Centímetros</option>
                                <option value="px" <?php if (isset($editar)) if ($editar->getUn() == 'px') echo 'selected'; ?>>Pixel</option>
                                <option value="%" <?php if (isset($editar)) if ($editar->getUn() == '%') echo 'selected'; ?>>Porcentagem</option>
                                <option value="vh" <?php if (isset($editar)) if ($editar->getUn() == 'vh') echo 'selected'; ?>>View Port Height</option>
                                <option value="vw" <?php if (isset($editar)) if ($editar->getUn() == 'vw') echo 'selected'; ?>>View Port Width</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="pergunta" for="quadro">Quadro:</label>
                            <select class="form-control" name="quadro" id="quadro">
                                <?php
                                $quadro = new Quadro('', '');
                                $q = $quadro->listar();
                                foreach ($q as $qd) {
                                    echo "<option value='{$qd["idquadro"]}'>{$qd["nome"]}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="pergunta" for="cor">Cor:</label>
                            <input class="form-control" type="color" name="cor" id="cor" value="<?php if ($editar) echo $editar->getCor(); ?>">
                        </div>
                        <button class="botao" type="submit" value="salvar" name="acao" id="acao">Salvar</button>
                        <?php if (isset($editar)) { ?>
                            <button class="pergunta" type="submit" value="excluir" name="acao" id="acao">Excluir</button>
                        <?php } ?>
                    </form>
                </div>
        </section>
        <hr>
        <div class="row justify-content-center">
        <?php
        $lista = $retangulo->listar();
        foreach($lista as $item){
            $q = new Retangulo($item['idretangulo'],$item['altura'],$item['base'],$item['cor'],$item['un'],$item['idquadro']);
            echo '<a draggable="true" href="index.php?id='.$q->getId().'">';
            echo $q->desenhar();
            echo '</a>';
        }
    ?>
        </div>
    </div>        
</body>
</html>
</center>