<center><?php
require_once('../classes/quadro.class.php');
$quadro = new Quadro('',1,'x','x');

$id = isset($_GET['id'])?$_GET['id']:0;
if ($id > 0){
    $dados = $quadro->listar(1,$id);
    $editar = new Quadro($dados[0]['idquadro'],
    $dados[0]['nome']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Formas geométricas</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Belanosima:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css.css">
</head>

<body>
    <div class="container">
        <br>
        <?php include "../formas.php"; ?>
        <br><br>
        <h1>Cadastro de Quadros</h1>
        <section>
                <div class="col-4">
                    <form action="acaoquadro.php" method="post">
                        <div class="form-group">
                            <label class="pergunta" for="id">ID:</label>
                            <input class="form-control" readonly type="text" name="id" id="id" value="<?php echo isset($editar) ? $editar->getId() : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label class="pergunta" for="nome">Nome:</label>
                            <input class="form-control" type="text" name='nome' id='nome' value='<?php if(isset($editar)) echo $editar->getNome(); ?>'>                        
                        </div>
                        <button class="botao" type="submit" value="salvar" name="acao" id="acao">Salvar</button>
                        <?php if (isset($editar)) { ?>
                            <button class="botao" type="submit" value="excluir" name="acao" id="acao">Excluir</button>
                        <?php } ?>
                    </form>
                </div>
        </section>
        <hr>
        <div class="row justify-content-center">
        <?php
if (isset($editar)) {
    $editar->listarFormas();
} else {
    $lista = $quadro->listar();
    foreach ($lista as $item) {
        $q = new Quadro($item['idquadro'], $item['nome']);
        echo '<a draggable="true" href="index.php?id=' . $q->getId() . '">';
        echo $q->getNome() . "<br>";
        echo '</a>';
    }
}
?>

        </div>
    </div>        
</body>
    
</body>
</html></center>