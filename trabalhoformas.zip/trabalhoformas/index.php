<center>
<!DOCTYPE html>
<html>
<head>
    <title>Formas geométricas</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Belanosima:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css.css">
</head>
<br><br><br><br>
<body>
    <h1>Formas geométricas</h1>
    <br>
    <a class="btn btn-dark" href="circulo/index.php" role="button">Círculo</a>
    <br><br>
    <a class="btn btn-dark" href="quadrado/index.php" role="button">Quadrado</a>
    <br><br>
    <a class="btn btn-dark" href="circulo/index.php" role="button">Retângulo</a>
    <br><br>
    <a class="btn btn-dark" href="quadrado/index.php" role="button">Triângulo</a>
    <br><br>
    <a class="btn btn-dark" href="quadrado/index.php" role="button">Quadro</a>
</body>
</html>
</center>